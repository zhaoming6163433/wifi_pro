let Chineseset ={
    china:"中国",
    america:"美国",
    japan:"日本",
    languagec:"中文",
    languagea:"英文",
    title:"WIFI参数设置",
    selanguage:"选择语言",
    networkname:"网络名称",
    networknamep:"请输入网络名称",
    networkpass:"网络密码",
    networkpassp:"请输入网络密码",
    area:"所在地区",
    areap:"请输入所在地区",
    dst:"夏令时(默认)",
    temp:"温度单位",
    save:"保存",
    manual:"使用手册",
    cancelText:"取消",
    searchText:"搜索",
    confirmText:"确定"
}
let Englishset = {
    china:"CHINA",
    america:"AMERICA",
    japan:"JAPAN",
    languagec:"Chinese",
    languagea:"English",
    title:"WIFI PARAMETER SETTING",
    selanguage:"SELECT THE LANGUAGE",
    networkname:"NET NAME",
    networknamep:"Please enter the network name",
    networkpass:"NET PASSWORD",
    networkpassp:"Please enter your network password",
    area:"AREA",
    areap:"Please enter area",
    dst:"DST(DEFAULT)",
    temp:"TEMP",
    save:"SAVE",
    manual:"OPERATING MANUAL",
    cancelText:"cancel",
    searchText:"search",
    confirmText:"confirm"
}
export default {
    Chineseset,
    Englishset
}
